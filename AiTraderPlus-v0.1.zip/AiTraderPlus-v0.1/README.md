# AiTraderPlus v0.1

AI-native Demo / Paper Trading Terminal.

## Included

- Professional dark trading terminal
- Watchlist
- Realtime simulated market data over WebSocket
- Candlestick chart
- Demo/Paper account
- Orders and Positions
- P&L / Equity / Margin
- Deterministic Risk Engine
- AI Copilot
- AI Market Analysis
- Structured AI Trade Proposal
- AI → Risk Engine → Paper Execution flow
- Emergency Stop
- Risk limits
- Trading Journal
- Portfolio endpoint
- Basic EMA/RSI/ATR indicators
- Basic EMA backtesting
- Docker deployment files

## Run

```bash
cp .env.example .env
python -m venv .venv
source .venv/bin/activate
pip install -r services/api/requirements.txt
uvicorn services.api.app:app --reload
```

Open http://127.0.0.1:8000

Or:

```bash
docker compose up --build
```

## Important safety boundary

v0.1 is **Paper Trading only**. It contains no real broker credentials, custody, payments, withdrawals, KYC/AML or live execution.

The intended production boundary is:

```text
AI
 ↓
Trade Proposal
 ↓
Deterministic Risk Engine
 ↓
Order Management
 ↓
Execution Provider
 ↓
Broker / Exchange
```

The AI must never be given direct access to broker credentials.

## Production next phase

- PostgreSQL + migrations
- Redis
- event bus
- OAuth2/OIDC + MFA
- RBAC and object-level authorization
- encrypted secrets / KMS
- immutable double-entry ledger
- real market-data adapters
- broker/exchange adapters
- realistic execution simulator
- production AI provider with scoped tools
- monitoring / tracing / alerting
- KYC/AML/payment services only after legal and licensing design

Never commit `.env` or API keys.
