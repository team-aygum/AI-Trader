
import asyncio
import math
import random
import uuid
from collections import deque
from datetime import datetime, timezone
from typing import Optional, Literal

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

app = FastAPI(title="AI Trading Terminal", version="0.1.0")

SYMBOLS = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "BTCUSD", "ETHUSD", "US100", "US500", "GER40", "UK100"]
BASE = {
    "EURUSD": 1.1700, "GBPUSD": 1.3500, "USDJPY": 147.20, "XAUUSD": 3375.0,
    "BTCUSD": 110000.0, "ETHUSD": 4200.0, "US100": 23500.0, "US500": 6350.0,
    "GER40": 24200.0, "UK100": 9050.0
}
prices = {s: BASE[s] for s in SYMBOLS}
history = {s: deque(maxlen=600) for s in SYMBOLS}
watchlist = list(SYMBOLS)
orders = []
positions = []
transactions = []
journal = []
alerts = []
audit_logs = []
events = deque(maxlen=500)
subscribers = set()

account = {
    "id": "DEMO-001",
    "type": "Paper Trading",
    "currency": "USD",
    "balance": 100000.0,
    "equity": 100000.0,
    "leverage": 20,
    "realized_pnl": 0.0,
    "unrealized_pnl": 0.0,
    "used_margin": 0.0,
    "free_margin": 100000.0,
}
risk_limits = {
    "max_risk_per_trade_pct": 1.0,
    "max_daily_loss_pct": 3.0,
    "max_drawdown_pct": 10.0,
    "max_positions": 8,
    "max_leverage": 10,
    "max_symbol_exposure_pct": 40.0,
}
settings = {"ai_mode": "SEMI-AUTO", "emergency_stop": False}

def now():
    return datetime.now(timezone.utc).isoformat()

def emit(kind, payload):
    evt = {"id": str(uuid.uuid4()), "type": kind, "ts": now(), "payload": payload}
    events.appendleft(evt)
    return evt

def seed_history():
    for s in SYMBOLS:
        p = BASE[s]
        for _ in range(300):
            drift = random.gauss(0, 0.0009 if p < 10 else 0.00045)
            o = p
            c = max(0.0001, p * (1 + drift))
            h = max(o, c) * (1 + random.random() * 0.0006)
            l = min(o, c) * (1 - random.random() * 0.0006)
            v = random.randint(500, 5000)
            history[s].append({"time": len(history[s]), "open": o, "high": h, "low": l, "close": c, "volume": v})
            p = c
        prices[s] = p

seed_history()

def spread_for(symbol):
    p = prices[symbol]
    return max(p * 0.00008, 0.00001) if p < 10000 else p * 0.00012

def quote(symbol):
    s = spread_for(symbol)
    return {"symbol": symbol, "bid": prices[symbol] - s/2, "ask": prices[symbol] + s/2,
            "spread": s, "change": change_pct(symbol), "high": max(x["high"] for x in history[symbol]) ,
            "low": min(x["low"] for x in history[symbol]), "volume": history[symbol][-1]["volume"], "status": "OPEN"}

def change_pct(symbol):
    h = history[symbol]
    if len(h) < 2: return 0
    return (h[-1]["close"] / h[-2]["close"] - 1) * 100

def sma(vals, n):
    if len(vals) < n: return sum(vals)/len(vals) if vals else 0
    return sum(vals[-n:]) / n

def ema(vals, n):
    if not vals: return 0
    k = 2/(n+1)
    e = vals[0]
    for x in vals[1:]: e = x*k + e*(1-k)
    return e

def rsi(vals, n=14):
    if len(vals) <= n: return 50
    gains, losses = [], []
    for i in range(1, len(vals)):
        d = vals[i]-vals[i-1]
        gains.append(max(d,0)); losses.append(max(-d,0))
    ag = sma(gains, n); al = sma(losses, n)
    if al == 0: return 100
    return 100 - (100/(1+ag/al))

def atr(candles, n=14):
    if len(candles) < 2: return 0
    tr = []
    for i in range(1, len(candles)):
        x, prev = candles[i], candles[i-1]
        tr.append(max(x["high"]-x["low"], abs(x["high"]-prev["close"]), abs(x["low"]-prev["close"])))
    return sma(tr, n)

def indicators(symbol):
    c = list(history[symbol])
    closes = [x["close"] for x in c]
    return {
        "sma20": sma(closes,20), "sma50": sma(closes,50), "ema20": ema(closes,20),
        "ema50": ema(closes,50), "ema200": ema(closes,200), "rsi": rsi(closes),
        "atr": atr(c), "price": prices[symbol],
    }

def recompute_account():
    unreal = 0.0
    used = 0.0
    for p in positions:
        q = prices[p["symbol"]]
        direction = 1 if p["side"] == "BUY" else -1
        unreal += (q-p["entry"]) * p["volume"] * direction * p["contract_size"]
        used += abs(q * p["volume"] * p["contract_size"]) / account["leverage"]
    account["unrealized_pnl"] = unreal
    account["equity"] = account["balance"] + unreal
    account["used_margin"] = used
    account["free_margin"] = account["equity"] - used

def risk_check(symbol, side, volume, sl: Optional[float]):
    recompute_account()
    if settings["emergency_stop"]:
        return False, "Emergency Stop is active"
    if len(positions) >= risk_limits["max_positions"]:
        return False, "Maximum positions limit reached"
    if account["leverage"] > risk_limits["max_leverage"]:
        return False, "Account leverage exceeds configured maximum"
    q = prices[symbol]
    if volume <= 0:
        return False, "Volume must be positive"
    if sl is None:
        return False, "Stop Loss is required by Risk Engine"
    risk_per_unit = abs(q-sl)
    contract = 1 if q > 1000 else 100000
    risk_cash = risk_per_unit * volume * contract
    max_risk = account["equity"] * risk_limits["max_risk_per_trade_pct"] / 100
    if risk_cash > max_risk:
        return False, f"Trade risk ${risk_cash:,.2f} exceeds ${max_risk:,.2f}"
    exposure = abs(q*volume*contract)
    if exposure > account["equity"] * risk_limits["max_symbol_exposure_pct"]/100:
        return False, "Symbol exposure limit exceeded"
    return True, "APPROVED"

def execute_market(symbol, side, volume, sl, tp, source="MANUAL"):
    ok, reason = risk_check(symbol, side, volume, sl)
    proposal = {"symbol":symbol,"side":side,"volume":volume,"sl":sl,"tp":tp,"source":source}
    audit_logs.append({"ts":now(),"action":"TRADE_PROPOSAL","proposal":proposal,"risk":reason})
    if not ok:
        emit("OrderRejected", {"reason":reason, **proposal})
        raise HTTPException(400, reason)
    fill = prices[symbol] + (spread_for(symbol)/2 if side=="BUY" else -spread_for(symbol)/2)
    oid = str(uuid.uuid4())[:8]
    order = {"id":oid,"symbol":symbol,"side":side,"type":"MARKET","volume":volume,
             "price":fill,"sl":sl,"tp":tp,"status":"FILLED","created_at":now(),
             "filled_volume":volume,"commission":abs(fill*volume)*0.00002,"slippage":abs(fill-prices[symbol])}
    orders.insert(0, order)
    contract = 1 if fill > 1000 else 100000
    pos = {"id":str(uuid.uuid4())[:8],"symbol":symbol,"side":side,"volume":volume,
           "entry":fill,"sl":sl,"tp":tp,"open_time":now(),"commission":order["commission"],
           "contract_size":contract,"strategy":source}
    positions.append(pos)
    transactions.append({"id":str(uuid.uuid4())[:8],"type":"Trade","amount":-order["commission"],"ts":now()})
    journal.insert(0, {"id":oid,"symbol":symbol,"side":side,"entry":fill,"status":"OPEN","strategy":source,"ai_analysis":"AI/Risk-approved proposal"})
    emit("OrderFilled", order)
    emit("PositionOpened", pos)
    recompute_account()
    return order, pos

class OrderIn(BaseModel):
    symbol: str
    side: Literal["BUY","SELL"]
    volume: float = Field(gt=0)
    sl: Optional[float] = None
    tp: Optional[float] = None
    source: str = "MANUAL"

class RiskSettings(BaseModel):
    max_risk_per_trade_pct: float = Field(gt=0, le=10)
    max_daily_loss_pct: float = Field(gt=0, le=50)
    max_drawdown_pct: float = Field(gt=0, le=90)
    max_positions: int = Field(gt=0, le=100)
    max_leverage: float = Field(gt=0, le=100)
    max_symbol_exposure_pct: float = Field(gt=0, le=100)

class AIQuery(BaseModel):
    message: str
    symbol: Optional[str] = "EURUSD"

class BacktestIn(BaseModel):
    symbol: str
    initial_balance: float = 100000
    risk_pct: float = 1
    fast: int = 20
    slow: int = 50
    start: Optional[int] = 0
    end: Optional[int] = 299

@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(open("static/index.html", encoding="utf-8").read())

@app.get("/api/health")
def health():
    recompute_account()
    return {"status":"ok","time":now(),"services":{"api":"ok","market_data":"ok","risk_engine":"ok","execution":"paper","ai":"ready"}}

@app.get("/api/account")
def get_account():
    recompute_account()
    return {**account, "free_margin": account["free_margin"], "margin_level": (account["equity"]/account["used_margin"]*100 if account["used_margin"] else 0),
            "risk_limits":risk_limits, "settings":settings}

@app.get("/api/symbols")
def get_symbols():
    return [quote(s) for s in watchlist]

@app.get("/api/candles/{symbol}")
def candles(symbol: str, limit: int=200):
    if symbol not in history: raise HTTPException(404, "Unknown symbol")
    return list(history[symbol])[-min(limit,600):]

@app.get("/api/indicators/{symbol}")
def get_indicators(symbol: str):
    if symbol not in history: raise HTTPException(404, "Unknown symbol")
    return indicators(symbol)

@app.get("/api/orders")
def get_orders(): return orders[:100]

@app.get("/api/positions")
def get_positions():
    recompute_account()
    out=[]
    for p in positions:
        q=prices[p["symbol"]]
        direction=1 if p["side"]=="BUY" else -1
        pnl=(q-p["entry"])*p["volume"]*direction*p["contract_size"]
        out.append({**p,"current":q,"unrealized_pnl":pnl})
    return out

@app.post("/api/orders")
def create_order(o: OrderIn):
    if o.symbol not in prices: raise HTTPException(404, "Unknown symbol")
    return execute_market(o.symbol,o.side,o.volume,o.sl,o.tp,o.source)[0]

@app.post("/api/positions/{pid}/close")
def close_position(pid: str):
    p = next((x for x in positions if x["id"]==pid),None)
    if not p: raise HTTPException(404,"Position not found")
    q=prices[p["symbol"]]
    direction=1 if p["side"]=="BUY" else -1
    pnl=(q-p["entry"])*p["volume"]*direction*p["contract_size"]-p["commission"]
    account["balance"] += pnl
    account["realized_pnl"] += pnl
    positions.remove(p)
    journal.insert(0, {"id":p["id"],"symbol":p["symbol"],"side":p["side"],"entry":p["entry"],"exit":q,"pnl":pnl,"status":"CLOSED","strategy":p["strategy"]})
    emit("PositionClosed", {"position_id":pid,"pnl":pnl})
    recompute_account()
    return {"ok":True,"pnl":pnl}

@app.get("/api/portfolio")
def portfolio():
    recompute_account()
    realized = account["realized_pnl"]
    unreal = account["unrealized_pnl"]
    return {"balance":account["balance"],"equity":account["equity"],"realized_pnl":realized,
            "unrealized_pnl":unreal,"drawdown":max(0,100-account["equity"]/100000*100),
            "win_rate": 0 if not journal else round(sum(1 for x in journal if x.get("pnl",0)>0)/max(1,sum(1 for x in journal if "pnl" in x))*100,1),
            "profit_factor":1.0,"sharpe":0.0,"sortino":0.0,"exposure":sum(abs(prices[p["symbol"]]*p["volume"]*p["contract_size"]) for p in positions),
            "positions":len(positions)}

@app.get("/api/risk")
def risk():
    recompute_account()
    return {"limits":risk_limits,"account_equity":account["equity"],"used_margin":account["used_margin"],
            "exposure":sum(abs(prices[p["symbol"]]*p["volume"]*p["contract_size"]) for p in positions),
            "status":"HALTED" if settings["emergency_stop"] else "ACTIVE"}

@app.put("/api/risk")
def set_risk(r: RiskSettings):
    risk_limits.update(r.model_dump())
    audit_logs.append({"ts":now(),"action":"RISK_LIMITS_UPDATED","value":r.model_dump()})
    return risk_limits

@app.post("/api/emergency-stop")
def emergency():
    settings["emergency_stop"] = True
    for o in orders:
        if o["status"]=="PENDING": o["status"]="CANCELLED"
    emit("RiskLimitReached",{"reason":"EMERGENCY_STOP"})
    return settings

@app.post("/api/emergency-reset")
def emergency_reset():
    settings["emergency_stop"] = False
    return settings

@app.post("/api/ai")
def ai(q: AIQuery):
    s=q.symbol if q.symbol in prices else "EURUSD"
    ind=indicators(s)
    trend="Bullish" if ind["ema20"]>ind["ema50"] else "Bearish"
    momentum="Strong" if abs(ind["rsi"]-50)>12 else "Moderate"
    volatility="High" if ind["atr"]/max(ind["price"],1)>0.01 else "Medium"
    support=min(x["low"] for x in list(history[s])[-30:])
    resistance=max(x["high"] for x in list(history[s])[-30:])
    msg=q.message.lower()
    if "risk" in msg or "пози" in msg:
        answer=f"Portfolio risk: {len(positions)} open positions, exposure {portfolio()['exposure']:,.0f}, margin used {account['used_margin']:,.0f}. Deterministic Risk Engine remains authoritative."
    else:
        answer=f"{s}: Trend {trend}, Momentum {momentum}, Volatility {volatility}. Key support {support:.5g}, resistance {resistance:.5g}. EMA20={ind['ema20']:.5g}, EMA50={ind['ema50']:.5g}, RSI={ind['rsi']:.1f}, ATR={ind['atr']:.5g}. This is scenario analysis, not a guaranteed outcome."
    result={"answer":answer,"analysis":{"trend":trend,"momentum":momentum,"volatility":volatility,"support":support,"resistance":resistance,"rsi":ind["rsi"],"atr":ind["atr"]},
            "tools":["get_market_data","get_positions","calculate_risk"],"timestamp":now()}
    audit_logs.append({"ts":now(),"action":"AI_REQUEST","request":q.model_dump(),"response":result})
    return result

@app.post("/api/ai/proposal")
def ai_proposal(q: AIQuery):
    s=q.symbol if q.symbol in prices else "EURUSD"
    ind=indicators(s); side="BUY" if ind["ema20"]>ind["ema50"] else "SELL"
    px=prices[s]; a=ind["atr"] or px*0.002
    sl=px-a*1.5 if side=="BUY" else px+a*1.5
    tp=px+a*3 if side=="BUY" else px-a*3
    contract=1 if px>1000 else 100000
    maxrisk=account["equity"]*risk_limits["max_risk_per_trade_pct"]/100
    vol=maxrisk/(abs(px-sl)*contract)
    vol=max(0.01,min(vol,1.0))
    ok, reason=risk_check(s,side,vol,sl)
    return {"symbol":s,"side":side,"order_type":"MARKET","position_size":round(vol,4),"entry":px,"stop_loss":sl,"take_profit":tp,
            "risk_pct":risk_limits["max_risk_per_trade_pct"],"risk_reward":"1:2","strategy":"EMA Trend","reason":"EMA20/EMA50 regime + ATR risk sizing","risk_status":reason,"approved":ok}

@app.post("/api/ai/execute")
def ai_execute(q: AIQuery):
    p=ai_proposal(q)
    if not p["approved"]: raise HTTPException(400,p["risk_status"])
    return execute_market(p["symbol"],p["side"],p["position_size"],p["stop_loss"],p["take_profit"],"AI-AUTO")[0]

@app.post("/api/backtest")
def backtest(b: BacktestIn):
    if b.symbol not in history: raise HTTPException(404,"Unknown symbol")
    candles=list(history[b.symbol])[max(0,b.start):min(len(history[b.symbol]),b.end+1)]
    if len(candles)<b.slow+5: raise HTTPException(400,"Not enough history")
    balance=b.initial_balance; equity=[balance]; trades=[]; side=None; entry=0; sl=0; tp=0
    for i in range(b.slow,len(candles)):
        closes=[x["close"] for x in candles[:i]]
        f=ema(closes,b.fast); slow=ema(closes,b.slow); px=candles[i]["close"]
        if side is None and f>slow:
            side="BUY"; entry=px; a=atr(candles[:i]) or px*.002; sl=px-a*1.5; tp=px+a*3
        elif side is None and f<slow:
            side="SELL"; entry=px; a=atr(candles[:i]) or px*.002; sl=px+a*1.5; tp=px-a*3
        if side=="BUY" and (px<=sl or px>=tp or f<slow):
            pnl=(px-entry)*(balance*b.risk_pct/100)/max(abs(entry-sl),1e-9)
            balance+=pnl; trades.append(pnl); side=None
        elif side=="SELL" and (px>=sl or px<=tp or f>slow):
            pnl=(entry-px)*(balance*b.risk_pct/100)/max(abs(entry-sl),1e-9)
            balance+=pnl; trades.append(pnl); side=None
        equity.append(balance)
    wins=sum(1 for x in trades if x>0); losses=sum(1 for x in trades if x<0)
    peak=equity[0]; maxdd=0
    for e in equity:
        peak=max(peak,e); maxdd=max(maxdd,(peak-e)/peak*100)
    gp=sum(x for x in trades if x>0); gl=-sum(x for x in trades if x<0)
    return {"symbol":b.symbol,"net_profit":balance-b.initial_balance,"gross_profit":gp,"gross_loss":gl,
            "win_rate":wins/max(1,len(trades))*100,"profit_factor":gp/max(gl,1e-9),
            "max_drawdown":maxdd,"number_of_trades":len(trades),"average_trade":sum(trades)/max(1,len(trades)),
            "largest_win":max(trades) if trades else 0,"largest_loss":min(trades) if trades else 0,
            "equity_curve":equity[-150:]}

@app.get("/api/journal")
def get_journal(): return journal[:100]

@app.get("/api/events")
def get_events(): return list(events)[:100]

@app.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()
    subscribers.add(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        subscribers.discard(websocket)

async def market_loop():
    while True:
        for s in SYMBOLS:
            p=prices[s]
            vol=0.00025 if p<100 else 0.0007
            new=max(0.00001,p*(1+random.gauss(0,vol)))
            o=p; c=new; h=max(o,c)*(1+random.random()*vol); l=min(o,c)*(1-random.random()*vol)
            history[s].append({"time":datetime.now(timezone.utc).timestamp(),"open":o,"high":h,"low":l,"close":c,"volume":random.randint(500,5000)})
            prices[s]=c
        recompute_account()
        payload={"quotes":[quote(s) for s in watchlist],"account":account}
        dead=[]
        for ws in list(subscribers):
            try: await ws.send_json(payload)
            except Exception: dead.append(ws)
        for ws in dead: subscribers.discard(ws)
        await asyncio.sleep(1)

@app.on_event("startup")
async def startup():
    asyncio.create_task(market_loop())

app.mount("/static", StaticFiles(directory="static"), name="static")
