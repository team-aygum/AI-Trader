# Roadmap

## v0.1 — Demo/Paper
- terminal
- market simulation
- orders
- positions
- risk
- AI analysis
- proposals
- paper execution
- backtest
- journal

## v0.2 — Data & Persistence
- PostgreSQL
- Redis
- historical market data
- real indicators
- strategy persistence
- user authentication

## v0.3 — AI Strategy Lab
- natural-language strategy builder
- strategy DSL
- walk-forward testing
- Monte Carlo
- optimizer
- AI portfolio analysis

## v0.4 — Broker Adapters
- MarketDataProvider
- ExecutionProvider
- BrokerProvider
- reconciliation
- partial fills
- realistic slippage/latency

## v1.0 — Production readiness
- MFA
- RBAC
- secrets vault
- immutable ledger
- observability
- compliance architecture
- legal/licensing review
