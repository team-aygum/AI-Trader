# AiTraderPlus Security Notes

This v0.1 is a paper-trading foundation and is not production financial infrastructure.

## Rules

1. No real broker credentials in the frontend.
2. No AI provider secrets in browser JavaScript.
3. AI proposals must pass deterministic server-side risk validation.
4. Emergency Stop must block new orders.
5. Financial balances must eventually be derived from an immutable ledger, not arbitrary frontend state.
6. Production authentication must use a mature OAuth2/OIDC solution with MFA.
7. Production APIs require RBAC, object-level authorization, rate limiting, audit logs and secure session management.
8. HTTPS must terminate at a trusted edge/proxy.
9. Paper and live environments must be completely separated.
10. Live execution must require an explicit server-side permission boundary.

FastAPI provides standard security primitives such as OAuth2/Bearer/API-key schemes, but production identity, token lifecycle, MFA and authorization policy still need to be implemented deliberately.
