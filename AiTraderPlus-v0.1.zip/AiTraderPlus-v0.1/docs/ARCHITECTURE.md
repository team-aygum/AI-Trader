# AiTraderPlus Architecture

```text
Browser
  |
  | HTTPS / WebSocket
  v
API
  |
  +-- Market Data
  +-- Trading / OMS
  +-- Risk Engine
  +-- Portfolio
  +-- AI Orchestrator
  +-- Backtesting
  +-- Audit
  |
  v
Paper Execution
```

## AI execution flow

```text
User / AI
   |
   v
Trade Proposal
   |
   v
Risk Engine
   |
   +---- REJECT
   |
   +---- APPROVE
             |
             v
        Order Engine
             |
             v
       Paper Execution
```

The v0.1 implementation intentionally keeps this as a single service so it is easy to run locally. The production architecture should split these boundaries into independently authenticated services.
